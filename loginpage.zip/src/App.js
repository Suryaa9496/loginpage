import React from 'react';
import LoginPage from './LoginPage';


const App = () => {
  return (
    <LoginPage/>
  );
};

export default App;
